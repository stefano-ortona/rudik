*** This folder contains all the experiment results evaluated in RuDiK.
The three Knowledge-Bases used for the main evaluation are the following:

- DBPedia: http://wiki.dbpedia.org/Downloads2015-10. Version: 3.7
Files: geo-coordinates_en.ttl, instance-types-transitive_en.ttl, mappingbased-properties_en.ttl, persondata_en.ttl, specific-mappingbased-properties_en.ttl.

- Yago: http://www.mpi-inf.mpg.de/departments/databases-and-information-systems/research/yago-naga/yago/downloads/. Version: 3.0.2
Files: yagoFacts.ttl, yagoDateFacts.ttl, yagoLiteralFacts.ttl, yagoTransitiveType.ttl.

- Wikidata: https://dumps.wikimedia.org/wikidatawiki/entities/. Version: 20160229.
Files: single Json dump with all non english literals removed.


*** Each subfolder contains a specific set of experiments with a detailed explanation.

*** Please refer to the online technical report for a detailed explanation and presentation of all the experiments - http://www.eurecom.fr/publication/5321.


