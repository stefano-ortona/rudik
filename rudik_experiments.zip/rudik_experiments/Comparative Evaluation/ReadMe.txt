*** This folder contains comparative evaluation results against AMIE+ (https://www.mpi-inf.mpg.de/departments/databases-and-information-systems/research/yago-naga/amie/). 
These experiments have been run on Yago2 and DBpedia 2.0 downloaded from their website.

*** Positive Folder. Contains comparative evaluation on positive rules. Each folder represents a different KB for a different system, with the following files:

- output_rules: up to best 30 output rules of the system, with truth label;
- statistics: for each target predicate, number of correct new induced facts and number of false induced facts;
- unknown_induced_facts: induced facts that are unknown and have been manually sampled and labelled as either true or false.

*** Negative Folder. Contains comparative evaluation on negative rules. 
Each folder represents a different KB for a different system, which contains a file for each target predicate with all the output rules and manually sampled annotations. 
For each output rule we show just the body of the rule, without head. 
It also contains an output_rules file, with all the rules in output for each target predicate with a truth value.
Each KB folder contains also a negativeExamples folder. This folder contains, for each target predicate, facts about the negation of the predicate derived with RuDiK negative examples generation strategy.
Such facts have been added to the original KB in order to enable AMIE+ in mining negative rules.


