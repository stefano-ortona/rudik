*** We show here, for each predicate, all output rules ranked according to our weight.
We also report truth values for the first ten rules, and for RuDiK output rules if these are not included in the first best ten ranked rules.


*** Some striking cases arise for founder negative (good rule at position 127 in the ranking) and academicAdvisor negative (good rule at position 150 in the ranking)


