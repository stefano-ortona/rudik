*** We show here output rules on DBPedia if we select negative examples with two different random strategies:
- random: we randomly sampled pairs of entities from the KB in size equal to positive examples;
- lcwa_random: we used the LCWA assumption that if the KB contains one or more values for a given subject and object, then it contains them all. We generate pairs with such a technique, and then randomly sampled a subset of those equal in size to positive examples. 
Each folder contains same kind of files and output of the ‘Quality of Rule Discovery’ folder.


