*** This folder contains experiments about some internal RuDiK setting and some KBs properties.
Each subfolder is a specific internal experiment with respective explanation.
All the experiments have been run on our version of DBPedia.


