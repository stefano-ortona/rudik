*** We show here output rules on DBPedia by varying the maximum length admissible for rule bodies. We report the output for values of maxPathLen parameter equal to 2 and 4.
When maxPathLen=4, the computation could not finish within 24 hours of running.
Thus we report here output rules after 24h of computation.
Each folder contains same kind of files and output of the ‘Quality of Rule Discovery’ folder.


