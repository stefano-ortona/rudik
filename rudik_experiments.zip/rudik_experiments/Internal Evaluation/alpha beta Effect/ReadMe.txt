*** We show here output rules on DBPedia by varying values of alpha and beta. 
The two log files contains output rules, for each predicate, with different values of alpha and beta. We varied alpha and beta with values of 0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.
curatedNegativeRules and curatedPositiveRules contains the union of all possible output rules outcome for every run, with a truth label used for evaluation.

*** The best performance in terms of accuracy was obtained with the following values:
- positive: alpha = 0.3, beta = 0.7;
- negative: alpha = 0.4, beta = 0.6.


