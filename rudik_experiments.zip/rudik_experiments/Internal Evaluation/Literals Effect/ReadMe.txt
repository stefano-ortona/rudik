*** We show here output rules on DBPedia without including literal values (dates, numbers, and strings), both for the positive and negative setting. 
Each folder contains same kind of files and output of the ‘Quality of Rule Discovery’ folder.


