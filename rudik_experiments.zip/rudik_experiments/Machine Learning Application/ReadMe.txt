*** This folder contains evaluation results on providing valid training examples to the Machine Learning inference system DeepDive (http://deepdive.stanford.edu/). We run their spouse showcases, first with 1K articles, and then with 1M articles.

*** Each experiments folder contains DeepDive calibration plots and data to generate these calibration plots for 4 different examples generation techniques:
- dbpediaPos_dbpediaNeg: get positive examples from DBPedia and negative examples with rules generated with RuDiK;
- dbpediaPos: get only positive examples from DBPedia;
- dbpediaPos+manual: get positive examples from DBPedia, and further negative and positive examples with manually defined rules on the input text;
- dbpediaPos+manual_sampled: same as above, but the size of negative examples is randomly sampled to make it of the same size with positive.

*** For DBPedia we used the online query endpoint (http://dbpedia.org/sparql) up to date 31.05.2016


