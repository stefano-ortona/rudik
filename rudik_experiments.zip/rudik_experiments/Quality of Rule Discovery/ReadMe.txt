*** Each folder contains specific results for a given KB.
More specifically, each folder contains two subfolders: positive and negative, reporting results for positive rules experiments and negative rules experiments respectively.

The negative and positive folder contains the set of output rules (with a truth value labels), and a file for each target predicate showing sampled manual annotations for individual triples.

*** The file containing output rules follow the following format:
<target_predicate> <tab> <output_rule_body> <tab> <truth_label>


